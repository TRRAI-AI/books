import React, { useState } from "react";
import { View, Text, Button, Image, FlatList, TextInput, ActivityIndicator, Linking, Alert, Platform } from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as OCR from "expo-mlkit-ocr";

type Candidate = { title: string; author: string };
type PriceRow = {
  key: string;
  title: string;
  author: string;
  ebay?: { min: number; median: number; max: number; count: number; examples?: any[] } | null;
  marktplaats?: { min: number; median: number; max: number; count: number; examples?: any[]; searchUrl?: string } | null;
};

const STOPWORDS = [
  "roman","druk","editie","edition","deel","pocket","uitgave","heruitgave","vol.","volume",
  "omnibus","serie","series","collector","paperback","hardcover",
];

const cleanLine = (s: string) => s
  .replace(/\b(ISBN|NUR|Uitgeverij|Publisher|Imprint)\b.*$/i, "")
  .replace(/\b\d{4}\b/g, "")
  .replace(/\b\d+(?:,\d{2})?\b/g, "")
  .replace(/[•·∙•]/g, " ")
  .replace(/\s{2,}/g, " ")
  .trim();

const stripSubtitle = (s: string) => s.split(/\s*[:–—-]\s*/)[0];

const looksLikeAuthor = (s: string) => {
  const t = s.trim();
  if (!t) return false;
  if (/^[A-ZÀ-ÖØ-Ý][A-Za-zÀ-ÖØ-öø-ÿ'’-]+(\s+[A-Z][A-Za-zÀ-ÖØ-öø-ÿ'’-]+)+$/.test(t)) return true;
  if (/^[A-Z][A-Za-z'’-]+,\s*[A-Z][A-Za-z'’-]+$/.test(t)) return true;
  if (/^(?:[A-Z]\.\s*){1,3}[A-Z][A-Za-z'’-]+$/.test(t)) return true;
  const words = t.split(/\s+/);
  const caps = words.filter(w => /^[A-ZÀ-ÖØ-Ý][\w’'-]+$/.test(w)).length;
  return words.length <= 4 && caps >= 1;
};

const looksLikeTitle = (s: string) => {
  const t = stripSubtitle(s).trim();
  if (t.length < 4) return false;
  const low = t.toLowerCase();
  if (STOPWORDS.some(w => low.includes(w))) return t.split(/\s+/).length >= 2;
  return /[a-zA-ZÀ-ÖØ-öø-ÿ]/.test(t);
};

const uniqKey = (c: Candidate) =>
  c.title.toLowerCase().replace(/\W+/g, " ").trim() + "|" + c.author.toLowerCase().replace(/\W+/g, " ").trim();

// <<< ZET JE BACKEND URL HIER >>>
const backendUrl = "http://localhost:3000";

export default function App() {
  const [img, setImg] = useState<string | null>(null);
  const [cands, setCands] = useState<Candidate[]>([]);
  const [prices, setPrices] = useState<{ items: PriceRow[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const takePhoto = async () => {
    let perm;
    if (Platform.OS !== "web") {
      perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) { Alert.alert("Camera", "Camera-toestemming is nodig."); return; }
    }
    const shot = await ImagePicker.launchCameraAsync({ quality: 0.7 });
    if (!shot.canceled) {
      const uri = shot.assets[0].uri;
      setImg(uri);
      await runOcr(uri);
    }
  };

  const runOcr = async (uri: string) => {
    const res = await OCR.scanFromURLAsync(uri, { languageHints: ["nl", "en"] });
    const lines = res.blocks.flatMap(b => b.lines.map(l => cleanLine(l.text))).filter(Boolean);

    const titles = new Set<string>();
    const authors = new Set<string>();
    for (const raw of lines) {
      const base = stripSubtitle(raw);
      if (looksLikeAuthor(base)) authors.add(base);
      if (looksLikeTitle(base)) titles.add(base);
    }

    const tArr = Array.from(titles);
    const aArr = Array.from(authors);

    const pairs: Candidate[] = [];
    for (const t of tArr) {
      let best: string | null = null;
      let bestScore = Infinity;
      for (const a of aArr) {
        const score = Math.abs(t.length - a.length * 2.5);
        if (score < bestScore) { best = a; bestScore = score; }
      }
      if (best) pairs.push({ title: t, author: best });
    }

    const seen = new Set<string>();
    const uniq = pairs.filter(p => {
      const k = uniqKey(p);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    }).slice(0, 8);

    setCands(uniq);
  };

  const fetchPrices = async () => {
    if (!cands.length) return;
    setLoading(true);
    try {
      const res = await fetch(`${backendUrl}/prices-by-ta`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: cands }),
      });
      const json = await res.json();
      setPrices(json);
    } catch (e) {
      Alert.alert("Fout", "Kon prijzen niet ophalen.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const openDeeplink = (site: "marktplaats" | "ebay", t: string, a: string) => {
    const q = encodeURIComponent(`${t} ${a}`);
    const url = site === "marktplaats"
      ? `https://www.marktplaats.nl/q/${q}/`
      : `https://www.ebay.nl/sch/i.html?_nkw=${q}`;
    Linking.openURL(url).catch(() => Alert.alert("Kon link niet openen"));
  };

  return (
    <View style={{ flex: 1, padding: 12 }}>
      <Button title="Foto maken" onPress={takePhoto} />
      {img && <Image source={{ uri: img }} style={{ width: "100%", height: 220, marginTop: 8 }} />}

      <Text style={{ marginTop: 10, fontWeight: "600" }}>Kandidaten (pas aan indien nodig):</Text>
      <FlatList
        data={cands}
        keyExtractor={(x, i) => i.toString()}
        renderItem={({ item, index }) => (
          <View style={{ marginVertical: 8, borderBottomWidth: 1, paddingBottom: 8 }}>
            <Text style={{ fontWeight: "700" }}>Boek #{index + 1}</Text>
            <Text>Titel</Text>
            <TextInput
              value={item.title}
              onChangeText={(v) => {
                const next = [...cands];
                next[index] = { ...next[index], title: v };
                setCands(next);
              }}
              style={{ borderWidth: 1, padding: 6 }}
            />
            <Text style={{ marginTop: 6 }}>Auteur</Text>
            <TextInput
              value={item.author}
              onChangeText={(v) => {
                const next = [...cands];
                next[index] = { ...next[index], author: v };
                setCands(next);
              }}
              style={{ borderWidth: 1, padding: 6 }}
            />
            <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
              <Button title="Open Marktplaats" onPress={() => openDeeplink("marktplaats", item.title, item.author)} />
              <Button title="Open eBay" onPress={() => openDeeplink("ebay", item.title, item.author)} />
            </View>
          </View>
        )}
      />

      <Button title="Zoek prijzen" onPress={fetchPrices} />
      {loading && <ActivityIndicator style={{ marginTop: 8 }} />}

      {prices && (
        <FlatList
          style={{ marginTop: 12 }}
          data={prices.items}
          keyExtractor={(x) => x.key}
          renderItem={({ item }) => (
            <View style={{ paddingVertical: 8, borderBottomWidth: 1 }}>
              <Text style={{ fontWeight: "700" }}>{item.title} — {item.author}</Text>
              <Text>eBay: €{item.ebay?.median ?? "—"} (min {item.ebay?.min ?? "—"} / max {item.ebay?.max ?? "—"}) • {item.ebay?.count ?? 0} hits</Text>
              <Text>Marktplaats: €{item.marktplaats?.median ?? "—"} (min {item.marktplaats?.min ?? "—"} / max {item.marktplaats?.max ?? "—"}) • {item.marktplaats?.count ?? 0} hits</Text>
              {!!item.marktplaats?.searchUrl && (
                <Text style={{ color: "blue" }} onPress={() => Linking.openURL(item.marktplaats!.searchUrl!)}>
                  Bekijk zoekresultaten op Marktplaats
                </Text>
              )}
            </View>
          )}
        />
      )}
    </View>
  );
}
