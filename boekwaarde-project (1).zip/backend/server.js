import express from "express";
import fetch from "node-fetch";
import { JSDOM } from "jsdom";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const EBAY_BEARER = process.env.EBAY_BEARER; // Vereist eBay dev OAuth

// ------- Cache (in-memory) -------
const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 uur
const cache = new Map(); // key -> { t: Date.now(), value }

function getCache(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.t > CACHE_TTL_MS) { cache.delete(key); return null; }
  return hit.value;
}
function setCache(key, value) {
  cache.set(key, { t: Date.now(), value });
}

// ------- Utils -------
const normalizeQuery = ({ title, author }) => `"${title.trim()}" "${author.trim()}"`;

const summarizeEUR = (arr) => {
  const prices = arr.filter(x => typeof x === "number").sort((a,b)=>a-b);
  if (!prices.length) return null;
  const mid = Math.floor(prices.length/2);
  const median = prices.length % 2 ? prices[mid] : (prices[mid-1] + prices[mid]) / 2;
  return {
    min: prices[0],
    median: Number(median.toFixed(2)),
    max: prices[prices.length - 1],
    count: prices.length
  };
};

// ------- eBay -------
async function ebayByTitleAuthor({ title, author }) {
  if (!EBAY_BEARER) return null;
  try {
    const q = normalizeQuery({ title, author });
    const url = new URL("https://api.ebay.com/buy/browse/v1/item_summary/search");
    url.searchParams.set("q", q);
    url.searchParams.set("limit", "50");

    const res = await fetch(url.toString(), { headers: { Authorization: `Bearer ${EBAY_BEARER}` }});
    if (!res.ok) return null;
    const data = await res.json();

    const eur = [];
    const examples = [];
    for (const it of (data.itemSummaries || [])) {
      const p = it.price;
      if (p?.currency === "EUR" && p?.value) {
        const val = Number(p.value);
        eur.push(val);
        if (examples.length < 5) examples.push({ title: it.title, price: val, url: it.itemWebUrl });
      }
    }
    const stats = summarizeEUR(eur);
    return stats ? { ...stats, examples } : null;
  } catch (e) {
    console.error("eBay error", e);
    return null;
  }
}

// ------- Marktplaats (prototype) -------
async function marktplaatsByTitleAuthor({ title, author }) {
  try {
    const q = encodeURIComponent(`${title} ${author}`);
    const url = `https://www.marktplaats.nl/q/${q}/`;
    const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" }});
    if (!res.ok) return null;
    const html = await res.text();
    const dom = new JSDOM(html);
    const doc = dom.window.document;

    const prices = [];
    const examples = [];
    doc.querySelectorAll("[data-testid='listing-item']").forEach(card => {
      const priceEl = card.querySelector("[data-testid='price']");
      const titleEl = card.querySelector("[data-testid='listing-title']");
      const linkEl  = card.querySelector("a[href]");
      if (!priceEl || !linkEl) return;
      const raw = priceEl.textContent || "";
      const m = raw.replace(/\./g, "").match(/(\d+)(?:,\d{2})?/);
      if (!m) return;
      const val = parseInt(m[1], 10);
      if (!isNaN(val)) {
        prices.push(val);
        if (examples.length < 5) {
          const href = linkEl.getAttribute("href");
          const abs = href?.startsWith("http") ? href : new URL(href || "", "https://www.marktplaats.nl").toString();
          examples.push({ title: titleEl?.textContent?.trim(), price: val, url: abs });
        }
      }
    });

    const stats = summarizeEUR(prices);
    return stats ? { ...stats, examples, searchUrl: url } : null;
  } catch (e) {
    console.error("Marktplaats error", e);
    return null;
  }
}

// ------- API -------
app.post("/prices-by-ta", async (req, res) => {
  const { items = [] } = req.body; // [{ title, author }]
  const out = [];

  for (const it of items) {
    const key = `${it.title}|${it.author}`;
    const cacheKey = `ta:${key}`;
    const cached = getCache(cacheKey);
    if (cached) {
      out.push(cached);
      continue;
    }

    const [ebay, mp] = await Promise.all([
      ebayByTitleAuthor(it),
      marktplaatsByTitleAuthor(it),
    ]);

    const row = {
      key,
      title: it.title,
      author: it.author,
      ebay: ebay || null,
      marktplaats: mp || null,
    };

    setCache(cacheKey, row);
    out.push(row);
  }

  res.json({ items: out });
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`Backend running on :${PORT}`));
